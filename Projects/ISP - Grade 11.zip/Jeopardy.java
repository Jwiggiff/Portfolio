/*
    Josh Friedman
    Jeopardy
    Mr. Rosen
    January 16, 2019
    This is a two player Jeopardy game in Java.
	The splashscreen displays the name of the program, the slogan, and an animation.
	The mainMenu screen displays 4 options for the user to choose.
	The instructions screen displays instructions for how to play Jeopardy.
	The highscore screen displays the top 10 highscores stored in a file.
	The round1 screen dispalys the round 1 board and asks the user to choose a card.
	The round2 screen dispalys the round 2 board and asks the user to choose a card.
	The askQuestion screen displays the current category and a question from that category and asks the user for the answer.
	The round3 screen dispalys the final category and asks both players for a bet. Then it dispalys the final question and gives each player 30 seconds to answer.

		VARIABLES
    NAME            TYPE            DESCRIPTION
    --------------------------------------------------
    c               Console         This variable is the Console to draw on.
    board           String[][]      This variable stores the dollar amounts in each card.
    questions       String[][]      This variable stres the questions for each card.
    answers         String[][]      This variable stores the answers for each card.
    playerNames     String[]        This variable stores the current playerNames.
    categories      String[]        This variable stores the 5 categories currently being used.
    oldCategories   String[]        This variable stores the old categories that have already been used in this game.
    dailyDoubles    int[][]         This variable stores which card is a daily double.
    scores          int[]           This variable stores the players' current scores.
    playerOneTurn   boolean         This variable stores whether it is player one's turn or not.
    done            boolean         This variable stores whether the user chose to exit from the menu or not.
*/

// The "Jeopardy" class.
import java.awt.*;
import hsa.*;
import java.io.*;
import javax.swing.JOptionPane;
import java.util.Date;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;

public class Jeopardy
{
    //Variable Declaration
    static Console c;           // The output console
    String[] [] board = new String [5] [5];
    String[] [] questions = new String [5] [5];
    String[] [] answers = new String [5] [5];
    String[] playerNames = new String [2];
    String[] categories = new String [5];
    String[] oldCategories = new String [10];
    int[] [] dailyDoubles = new int [5] [5];
    int[] scores = new int [2];
    boolean playerOneTurn = true;
    static boolean done = false;


    /*
      This method returns a boolean of whether a string value is in an array.
      ----------------------------------------------------------
      Local Variables:
      NAME      TYPE            DESCRIPTION
      ----------------------------------------------------------
      array     String[]        This variable is the array to check inside.
      value     String          This variable is the string to look for.

      Global Variables: None.
      ----------------------------------------------------------
      The for loop loops through each index of the array.
      The if statement checks if that index in the array is equal to the value.
    */
    private boolean inArray (String[] array, String value)
    {
	for (int x = 0 ; x < array.length ; x++)
	{
	    if (array [x] != null && array [x].toLowerCase ().equals (value.toLowerCase ()))
		return true;
	}
	return false;
    }


    /*
      This method returns the index that a value is in an array.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE        DESCRIPTION
      ----------------------------------------------------------
      array       String[]    This variable is the array to look inside.
      value       String      This variable is the value to look for.

      Global Variables: None.
      ----------------------------------------------------------
      The for loop loops through each index of the array.
      The if statement checks if that index in the array is equal to the value.
    */
    public static int indexInArray (String[] array, String value)
    {
	for (int x = 0 ; x < array.length ; x++)
	{
	    if (array [x] != null && array [x].toLowerCase ().equals (value.toLowerCase ()))
		return x;
	}
	return -1;
    }


    /*
      This method returns the index that a value is in an array.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE        DESCRIPTION
      ----------------------------------------------------------
      array       int[]       This variable is the array to look inside.
      value       int         This variable is the value to look for.

      Global Variables: None.
      ----------------------------------------------------------
      The for loop loops through each index of the array.
      The if statement checks if that index in the array is equal to the value.
    */
    public static int indexInArray (int[] array, int value)
    {
	for (int x = 0 ; x < array.length ; x++)
	{
	    if (array [x] == value)
		return x;
	}
	return -1;
    }


    /*
      This method populates the categories array with 5 random categories.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      input       BufferedReader    This variable is used to read the categories file.
      cats        String[]          This variable stores all of the categories.
      total       int               This variable stores the total categories in the oldCategories array.
      a           String            This variable is a temporary variable that stores the line read from the file.
      x           int               This variable stores a random number from 0 to the length of cats.

      Global Variables:
      NAME            TYPE              DESCRIPTION
      ----------------------------------------------------------
      categories      String[]          This variable stores the 5 categories currently being used.
      oldCategories   String[]          This variable stores the old categories that have already been used in this game.

      ----------------------------------------------------------
      The first for loop loops through each index of of oldCategories.
      The first if statement checks if that index of oldCategories is null, and if it is sets total to that index.
      The second for loop adds each category from the categories array to the oldCategories array.
      The third for loop loops through each index in the category.
      The while loop sets that index of the categories array to a random category that has not already been used.
    */
    private void getRandCategories ()
    {
	BufferedReader input;
	String[] cats;
	int total = 0;

	//get length of oldCategories
	for (int i = 0 ; i < oldCategories.length ; i++)
	{
	    if (oldCategories [i] == null)
	    {
		total = i;
		break;
	    }
	}

	//put current categories into oldCategories
	for (int i = 0 ; i < categories.length ; i++)
	    oldCategories [i + total] = categories [i];

	try
	{
	    input = new BufferedReader (new FileReader ("lib/Categories.txt"));
	    String a = input.readLine ();
	    cats = a.split (", ");

	    for (int i = 0 ; i < categories.length ; i++)
	    {
		while (true)
		{
		    int x = (int) (Math.random () * cats.length);
		    if (!inArray (categories, cats [x]) && !inArray (oldCategories, cats [x]))
		    {
			categories [i] = cats [x];
			break;
		    }
		}
	    }
	}
	catch (IOException e)
	{
	    JOptionPane.showMessageDialog (null, "Missing dependency files!", "Missing Dependencies", JOptionPane.ERROR_MESSAGE);
	}
    }


    /*
      This method populates the questions and answers array with 5 questions and answers for each category.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      input       BufferedReader    This variable is used to read the categories file.
      q           String[]          This variable is an array of the questions in the category.
      as          String[]          This variable is an array of the answers in the category.
      total       int               This variable is the total number of questions in the category.
      fileName    String            This variable stores the file name to read the questions and answers from.
      a           String            This variable is a temporary variable to store the line of the file.
      b           String[]          This variable is the array with the question and answer for each question.

      Global Variables:
      NAME            TYPE              DESCRIPTION
      ----------------------------------------------------------
      categories      String[]          This variable stores the 5 categories currently being used.
      questions       String[][]        This variable stres the questions for each card.
      answers         String[][]        This variable stores the answers for each card.

      ----------------------------------------------------------
      The first for loop loops through each index of the categories array.
      The first while loop keeps reading lines from the file until the line is null.
      The second for loop loops through each question and sets the b array to the question and the answer.
      The second while loop populates the questions and answers array with 5 random questions and answers.
    */
    private void getQuestions ()
    {
	BufferedReader input;
	String[] q;
	String[] as;

	for (int z = 0 ; z < categories.length ; z++)
	{
	    int total = 0;
	    try
	    {
		String fileName = "lib/Questions/" + categories [z] + ".txt";
		input = new BufferedReader (new FileReader (fileName));
		while (true)
		{
		    String a = input.readLine ();
		    if (a == null)
			break;
		    total++;
		}

		q = new String [total];
		as = new String [total];
		input = new BufferedReader (new FileReader (fileName));
		for (int i = 0 ; i < total ; i++)
		{
		    String[] b = input.readLine ().split ("-");
		    q [i] = b [0];
		    as [i] = b [1];
		}
		int i = 0;
		while (i < 5)
		{
		    int x = (int) (Math.random () * total);
		    if (q [x] != "")
		    {
			questions [z] [i] = q [x];
			answers [z] [i] = as [x];
			q [x] = "";
			i++;
		    }
		}
	    }
	    catch (IOException e)
	    {
	    }
	}
    }


    /*
      This method displays a category and a question from that category and asks the user for an answer.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      category    String            This variable is the category that the user selected.
      question    String            This variable is the questons that the user selected.
      cat         String            This variable is a string used for the title section.
      answer      String            This variable is the answer that the user inputs.
      plr         int               This variable gets the index of the player who's turn it is.

      Global Variables:
      NAME            TYPE              DESCRIPTION
      ----------------------------------------------------------
      board           String[][]      This variable stores the dollar amounts in each card.
      questions       String[][]      This variable stres the questions for each card.
      answers         String[][]      This variable stores the answers for each card.
      playerNames     String[]        This variable stores the current playerNames.
      categories      String[]        This variable stores the 5 categories currently being used.
      scores          int[]           This variable stores the players' current scores.
      playerOneTurn   boolean         This variable stores whether it is player one's turn or not.

      ----------------------------------------------------------
      The if/else statement checks if the answer that the user inputted is correct or not.
    */
    private void askQuestion (String category, String question)
    {
	c.setCursor (2, 1);
	c.print (playerNames [0] + ":");
	c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
	c.print (playerNames [1] + ":");
	c.print ("$" + scores [0]);
	String cat = "Category: " + category;
	c.print (' ', 40 - cat.length () / 2 - String.valueOf (scores [0]).length () - 1);
	c.print (cat);
	c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
	c.print ("$" + scores [1]);

	c.println ("\n\n\n\n");
	c.println (question);
	c.println ("\n\n");
	c.print ("Who/What is ");
	String answer = c.readLine ();
	c.println ();
	int plr = playerOneTurn ? 0:
	1;
	if (answer.toLowerCase ().equals (answers [indexInArray (categories, category)] [indexInArray (questions [indexInArray (categories, category)], question)].toLowerCase ()))
	{
	    c.println ("Correct!");
	    scores [plr] += Integer.parseInt (board [indexInArray (categories, category)] [indexInArray (questions [indexInArray (categories, category)], question)].substring (1));
	}
	else
	{
	    c.println ("Incorrect!");
	    c.println ("The correct answer was \"" + answers [indexInArray (categories, category)] [indexInArray (questions [indexInArray (categories, category)], question)] + "\"");
	    scores [plr] -= Integer.parseInt (board [indexInArray (categories, category)] [indexInArray (questions [indexInArray (categories, category)], question)].substring (1));
	}
	c.println ("Press any key to continue...");
	c.getChar ();
    }


    /*
      This method displays a category and a question from that category and asks the user for an answer.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      category    String            This variable is the category that the user selected.
      question    String            This variable is the questons that the user selected.
      cat         String            This variable is a string used for the title section.
      answer      String            This variable is the answer that the user inputs.
      plr         int               This variable gets the index of the player who's turn it is.
      wager       int               This variable is the wager that the user inputted for a daily double.

      Global Variables:
      NAME            TYPE              DESCRIPTION
      ----------------------------------------------------------
      board           String[][]      This variable stores the dollar amounts in each card.
      questions       String[][]      This variable stres the questions for each card.
      answers         String[][]      This variable stores the answers for each card.
      playerNames     String[]        This variable stores the current playerNames.
      categories      String[]        This variable stores the 5 categories currently being used.
      scores          int[]           This variable stores the players' current scores.
      playerOneTurn   boolean         This variable stores whether it is player one's turn or not.

      ----------------------------------------------------------
      The if/else statement checks if the answer that the user inputted is correct or not.
    */
    private void askQuestion (String category, String question, int wager)
    {
	c.setCursor (2, 1);
	c.print (playerNames [0] + ":");
	c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
	c.print (playerNames [1] + ":");
	c.print ("$" + scores [0]);
	String cat = "Category: " + category;
	c.print (' ', 40 - cat.length () / 2 - String.valueOf (scores [0]).length () - 1);
	c.print (cat);
	c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
	c.print ("$" + scores [1]);

	c.println ("\n\n\n\n");
	c.println (question);
	c.println ("\n\n");
	c.print ("Who/What is ");
	String answer = c.readLine ();
	c.println ();
	int plr = playerOneTurn ? 0:
	1;
	if (answer.toLowerCase ().equals (answers [indexInArray (categories, category)] [indexInArray (questions [indexInArray (categories, category)], question)].toLowerCase ()))
	{
	    c.println ("Correct!");
	    scores [plr] += wager;
	}
	else
	{
	    c.println ("Incorrect!");
	    c.println ("The correct answer was \"" + answers [indexInArray (categories, category)] [indexInArray (questions [indexInArray (categories, category)], question)] + "\"");
	    scores [plr] -= wager;
	}
	c.println ("Press any key to continue...");
	c.getChar ();
    }


    /*
      This method displays the title at the top of the screen.
      ----------------------------------------------------------
      Local Variables:
      NAME              TYPE    DESCRIPTION
      ----------------------------------------------------------
      title             String  This variable stores the title to display at the top of the screen.
      f                 Font    This variable is the font used for drawString.
      x                 int     This variable is the width of the string in pixels.

      Global Variables: None.
      ----------------------------------------------------------
      No input/logic/loop is used.
    */
    private void title (String title)
    {
	c.clear ();
	c.println ();
	c.println ();
	Font f = new Font ("serif", Font.BOLD, 24);
	c.setFont (f);
	c.setColor (Color.blue);
	int x = (int) (320 - f.getStringBounds (title, new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	c.drawString (title, x, 20);
    }


    /*
      This method displays the top 10 highscores.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      input       BufferedReader    This variable is used to read the highscores file.
      highscores  String[][]        This variable stores the name and score of the top 10 scores.
      f           Font              This variable is the font used for drawString.
      tmp         String            This variable is a temporary variable to store the line from the file.

      Global Variables: None.
      ----------------------------------------------------------
      The first for loop populates the highscores array with the name and score of the top 10 highscores.
      The second for loop gets the total number of highscores.
      The third and fourth for loop bubble sort the highscores from greatest to least.
      the fifth for loop displays each highscore.
      The last if statement checks if the user pressed 'x', and if they did clears the highscores.
    */
    private void highscore ()
    {
	BufferedReader input;
	String[] [] highscores = new String [10] [2];
	Font f = new Font ("serif", Font.BOLD, 24);
	c.setFont (f);

	try
	{
	    input = new BufferedReader (new FileReader ("lib/highscores.txt"));
	    for (int i = 0 ; i < 10 ; i++)
	    {
		String tmp = input.readLine ();
		if (tmp != null)
		    highscores [i] = tmp.split (":");
	    }
	}
	catch (IOException e)
	{
	    new Message ("Highscore file missing!");
	}

	int total = highscores.length;
	for (int i = 0 ; i < highscores.length ; i++)
	    if (highscores [i] [0] == null)
	    {
		total = i;
		break;
	    }

	//Bubble sort highscores
	for (int i = 0 ; i < total - 1 ; i++)
	    for (int x = 0 ; x < total - i - 1 ; x++)
		if (Integer.parseInt (highscores [x] [1]) < Integer.parseInt (highscores [x + 1] [1]))
		{
		    String[] tmp = highscores [x];
		    highscores [x] = highscores [x + 1];
		    highscores [x + 1] = tmp;
		}

	title ("Highscores");
	c.setColor (Color.blue);
	c.fillRect (120, 70, 400, 30);
	c.setColor (Color.black);
	c.drawRect (120, 70, 200, 30);
	c.drawRect (320, 70, 200, 30);
	c.setColor (Color.white);
	c.drawString ("Name", 126, 93);
	c.drawString ("Score", 326, 93);
	for (int i = 0 ; i < 10 ; i++)
	{
	    c.setColor (Color.gray);
	    c.fillRect (120, 100 + i * 30, 400, 30);
	    c.setColor (Color.black);
	    c.drawRect (120, 100 + i * 30, 200, 30);
	    c.drawRect (320, 100 + i * 30, 200, 30);
	    if (highscores [i] [0] != null)
	    {
		c.drawString (highscores [i] [0], 126, 123 + i * 30);
		c.drawString (highscores [i] [1], 326, 123 + i * 30);

	    }
	}

	c.setCursor (24, 40 - "Press [x] to clear highscores or any other key to return to the main menu...".length () / 2);
	c.println ("Press [x] to clear highscores or any other key to return to the main menu...");
	char key = c.getChar ();
	if (key == 'x')
	{
	    PrintWriter output;
	    try
	    {
		output = new PrintWriter (new FileWriter ("lib/highscores.txt"));
		output.println ();
	    }
	    catch (IOException e)
	    {
	    }
	}
    }


    /*
      This method displays the instructions for how to use the program.
      ----------------------------------------------------------
      Local Variables: None.
      Global Variables: None.
      ----------------------------------------------------------
      No input/logic/loop is used.
    */
    private void instructions ()
    {
	title ("Instructions");

	c.println ("1. Find a friend to play with!");
	c.println ("2. Take turns choosing a category and a number");
	c.println ("3. A sentence will appear in the form of an answer. The player must answer in\n the form of a question. They will have 10 seconds to do so.");
	c.println ("4. If the answer is right, the player will gain the amount of points the card\n was worth. If they get it wrong, they will lose the amount that the card is\n worth.");
	c.println ("5. After all the cards have been chosen, round 2 will start. It is the same as\n round 1, but all the cards are doubled value and there are new categories and\n questions.");
	c.println ("6. After round 2 completes, the final round will begin.");
	c.println ("7. The category will appear, and each player will have a chance to enter how\n much they want to bet.");
	c.println ("8. After both players bet, the question will appear and each player will get a\n chance to answer.");
	c.println ();
	//c.println ("If a Daily Double appears:");
	c.println ();
	c.println ();
	c.setColor (Color.black);
	c.drawString ("If a Daily Double appears:", 0, 375);
	c.println ("Instead of the value assigned to the card, the player may choose how much they\n would like to bet ");
	c.println ();
	c.println ("Press any key to return to the main menu...");
	c.getChar ();
    }


    /*
      This method displays the round 1 board and asks the user to select a card.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE        DESCRIPTION
      ----------------------------------------------------------
      player      int         This variable stores the index of the player who's turn it is.
      turn        String      This variable is used to display who's turn it is in the title section.
      f           Font        This variable is the font used for drawString.
      choice      String[]    This variable is the array of the category and value that the user selected.
      a           String      This variable is a temporary variable to store the input of the user.
      wager       int         This variable stores the wager that the user inputted if they selected a daily double.
      score       int         This variable stores the score of the current player.
      limit       int         This variable stores the maximum that a user is allowed to wager for a daily double.
      wagerStr    String      This variable stores the wager as a string.

      Global Variables:
      NAME            TYPE            DESCRIPTION
      ----------------------------------------------------------
      board           String[][]      This variable stores the dollar amounts in each card.
      playerNames     String[]        This variable stores the current playerNames.
      categories      String[]        This variable stores the 5 categories currently being used.
      dailyDoubles    int[][]         This variable stores which card is a daily double.
      scores          int[]           This variable stores the players' current scores.
      playerOneTurn   boolean         This variable stores whether it is player one's turn or not.

      ----------------------------------------------------------
      No input/logic/loop is used.
    */
    private void round1 ()
    {
	title ("Round 1");
	c.setCursor (2, 1);
	c.print (playerNames [0] + ":");
	c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
	c.print (playerNames [1] + ":");
	c.print ("$" + scores [0]);
	int player = playerOneTurn ? 0:
	1;
	String turn = playerNames [player] + "'s turn";
	c.print (' ', 40 - turn.length () / 2 - String.valueOf (scores [0]).length () - 1);
	c.print (turn);
	c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
	c.print ("$" + scores [1]);

	Font f = new Font ("serif", Font.BOLD, 24);
	c.setFont (f);

	//Draws the board
	for (int col = 0 ; col < board.length ; col++)
	{
	    c.setColor (Color.blue);
	    c.fillRect (col * 128, 70, 128, 30);
	    c.setColor (Color.black);
	    c.drawRect (col * 128, 70, 128, 30);
	    c.setColor (Color.white);
	    c.drawString (categories [col], 6 + col * 128, 93);
	    for (int row = 0 ; row < board [col].length ; row++)
	    {
		c.setColor (Color.gray);
		c.fillRect (col * 128, 100 + row * 70, 128, 70);
		c.setColor (Color.black);
		c.drawRect (col * 128, 100 + row * 70, 128, 70);
		c.drawString (board [col] [row], 36 + col * 128, 140 + row * 70);
	    }
	}

	//Asks for input
	String[] choice;

	c.setCursor (23, 1);
	c.println ("Which would you like to choose?(Format: \"<category> for <value>\") or enter skip");
	while (true)
	{
	    c.setCursor (24, 1);
	    c.println ();
	    c.setCursor (24, 1);
	    String a = c.readLine ();

	    //FOR TESTING PURPOSES
	    if (a.equals ("skip"))
	    {
		for (int col = 0 ; col < 5 ; col++)
		{
		    for (int row = 0 ; row < 5 ; row++)
		    {
			board [col] [row] = "";
		    }
		}
		return;
	    }

	    choice = a.split ("for");
	    if (choice.length != 2)
		JOptionPane.showMessageDialog (null, "Invalid syntax! Proper syntax is:\n    \"<category> for <value>\"\nTry again!", "Invalid Syntax", JOptionPane.ERROR_MESSAGE);
	    else
	    {
		for (int i = 0 ; i < choice.length ; i++)
		    choice [i] = choice [i].trim ();
		if (choice [1].charAt (0) == '$')
		    choice [1] = choice [1].substring (1, choice [1].length ());
		if (inArray (categories, choice [0]))
		{
		    choice [0] = categories [indexInArray (categories, choice [0])];
		    if (inArray (new String[]
		    {
			"100", "200", "300", "400", "500"
		    }
		    , choice [1]) && board [indexInArray (categories, choice [0])] [Integer.parseInt (choice [1]) / 100 - 1] != "")
			break;
		    else
			JOptionPane.showMessageDialog (null, "Invalid value! Try again!", "Invalid Value", JOptionPane.ERROR_MESSAGE);
		}
		else
		    JOptionPane.showMessageDialog (null, "Invalid category! Try again!", "Invalid Category", JOptionPane.ERROR_MESSAGE);
	    }
	}
	title ("Round 1");

	if (dailyDoubles [indexInArray (categories, choice [0])] [Integer.parseInt (choice [1]) / 100 - 1] == 1)
	{
	    int wager;
	    c.println ("Daily Double!\n");
	    int score = scores [playerOneTurn ? 0:
	    1];
	    int limit;
	    if (score < 500)
		limit = 500;
	    else if (score < 1000)
		limit = 1000;
	    else
		limit = score;
	    c.println ("You may wager between $5 and $" + limit + "\n");
	    c.print ("How much would you like to wager? ");
	    while (true)
	    {
		String wagerStr = c.readLine ();
		if (wagerStr.charAt (0) == '$')
		    wagerStr = wagerStr.substring (1);
		try
		{
		    wager = Integer.parseInt (wagerStr);
		    if (wager >= 5 && wager <= limit)
			break;
		    new Message ("You cannot wager that amount! Try again!");
		}
		catch (NumberFormatException e)
		{
		}
	    }
	    askQuestion (choice [0], questions [indexInArray (categories, choice [0])] [indexInArray (board [indexInArray (categories, choice [0])], "$" + choice [1])], wager);
	}
	else
	{
	    askQuestion (choice [0], questions [indexInArray (categories, choice [0])] [indexInArray (board [indexInArray (categories, choice [0])], "$" + choice [1])]);
	}

	board [indexInArray (categories, choice [0])] [indexInArray (board [indexInArray (categories, choice [0])], "$" + choice [1])] = "";
	playerOneTurn = playerOneTurn ? false:
	true;
    }


    /*
      This method displays the round 2 board and asks the user to select a card.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE        DESCRIPTION
      ----------------------------------------------------------
      player      int         This variable stores the index of the player who's turn it is.
      turn        String      This variable is used to display who's turn it is in the title section.
      f           Font        This variable is the font used for drawString.
      choice      String[]    This variable is the array of the category and value that the user selected.
      a           String      This variable is a temporary variable to store the input of the user.
      wager       int         This variable stores the wager that the user inputted if they selected a daily double.
      score       int         This variable stores the score of the current player.
      limit       int         This variable stores the maximum that a user is allowed to wager for a daily double.
      wagerStr    String      This variable stores the wager as a string.

      Global Variables:
      NAME            TYPE            DESCRIPTION
      ----------------------------------------------------------
      board           String[][]      This variable stores the dollar amounts in each card.
      playerNames     String[]        This variable stores the current playerNames.
      categories      String[]        This variable stores the 5 categories currently being used.
      dailyDoubles    int[][]         This variable stores which card is a daily double.
      scores          int[]           This variable stores the players' current scores.
      playerOneTurn   boolean         This variable stores whether it is player one's turn or not.

      ----------------------------------------------------------
      No input/logic/loop is used.
    */
    private void round2 ()
    {
	title ("Round 2");
	c.setCursor (2, 1);
	c.print (playerNames [0] + ":");
	c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
	c.print (playerNames [1] + ":");
	c.print ("$" + scores [0]);
	int player = playerOneTurn ? 0:
	1;
	String turn = playerNames [player] + "'s turn";
	c.print (' ', 40 - turn.length () / 2 - String.valueOf (scores [0]).length () - 1);
	c.print (turn);
	c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
	c.print ("$" + scores [1]);

	Font f = new Font ("serif", Font.BOLD, 24);
	c.setFont (f);

	//Draws the board
	for (int col = 0 ; col < board.length ; col++)
	{
	    c.setColor (Color.blue);
	    c.fillRect (col * 128, 70, 128, 30);
	    c.setColor (Color.black);
	    c.drawRect (col * 128, 70, 128, 30);
	    c.setColor (Color.white);
	    c.drawString (categories [col], 6 + col * 128, 93);
	    for (int row = 0 ; row < board [col].length ; row++)
	    {
		c.setColor (Color.gray);
		c.fillRect (col * 128, 100 + row * 70, 128, 70);
		c.setColor (Color.black);
		c.drawRect (col * 128, 100 + row * 70, 128, 70);
		c.drawString (board [col] [row], 36 + col * 128, 140 + row * 70);
	    }
	}


	//Asks for input
	String[] choice;

	c.setCursor (23, 1);
	c.println ("Which would you like to choose?(Format: \"<category> for <value>\") or enter skip");
	while (true)
	{
	    c.setCursor (24, 1);
	    c.println ();
	    c.setCursor (24, 1);
	    String a = c.readLine ();

	    //FOR TESTING PURPOSES
	    if (a.equals ("skip"))
	    {
		for (int col = 0 ; col < 5 ; col++)
		{
		    for (int row = 0 ; row < 5 ; row++)
		    {
			board [col] [row] = "";
		    }
		}
		return;
	    }

	    choice = a.split ("for");
	    if (choice.length != 2)
		JOptionPane.showMessageDialog (null, "Invalid syntax! Proper syntax is:\n    \"<category> for <value>\"\nTry again!", "Invalid Syntax", JOptionPane.ERROR_MESSAGE);
	    else
	    {
		for (int i = 0 ; i < choice.length ; i++)
		    choice [i] = choice [i].trim ();
		if (choice [1].charAt (0) == '$')
		    choice [1] = choice [1].substring (1, choice [1].length ());
		if (inArray (categories, choice [0]))
		{
		    choice [0] = categories [indexInArray (categories, choice [0])];
		    if (inArray (new String[]
		    {
			"200", "400", "600", "800", "1000"
		    }
		    , choice [1]) && board [indexInArray (categories, choice [0])] [Integer.parseInt (choice [1]) / 200 - 1] != "")
			break;
		    else
			JOptionPane.showMessageDialog (null, "Invalid value! Try again!", "Invalid Value", JOptionPane.ERROR_MESSAGE);
		}
		else
		    JOptionPane.showMessageDialog (null, "Invalid category! Try again!", "Invalid Category", JOptionPane.ERROR_MESSAGE);
	    }
	}


	title ("Round 2");

	if (dailyDoubles [indexInArray (categories, choice [0])] [Integer.parseInt (choice [1]) / 200 - 1] == 1)
	{
	    int wager;
	    c.println ("Daily Double!\n");
	    int score = scores [playerOneTurn ? 0:
	    1];
	    int limit;
	    if (score < 500)
		limit = 500;
	    else if (score < 1000)
		limit = 1000;
	    else
		limit = score;
	    c.println ("You may wager between $5 and $" + limit + "\n");
	    c.print ("How much would you like to wager? ");
	    while (true)
	    {
		String wagerStr = c.readLine ();
		if (wagerStr.charAt (0) == '$')
		    wagerStr = wagerStr.substring (1);
		try
		{
		    wager = Integer.parseInt (wagerStr);
		    if (wager >= 5 && wager <= limit)
			break;
		    new Message ("You cannot wager that amount! Try again!");
		}
		catch (NumberFormatException e)
		{
		}
	    }
	    askQuestion (choice [0], questions [indexInArray (categories, choice [0])] [indexInArray (board [indexInArray (categories, choice [0])], "$" + choice [1])], wager);
	}
	else
	{
	    askQuestion (choice [0], questions [indexInArray (categories, choice [0])] [indexInArray (board [indexInArray (categories, choice [0])], "$" + choice [1])]);
	}

	board [indexInArray (categories, choice [0])] [indexInArray (board [indexInArray (categories, choice [0])], "$" + choice [1])] = "";
	playerOneTurn = playerOneTurn ? false:
	true;

	c.println ("Category: " + categories [0]);
    }


    /*
      This method displays the round 3 board and asks the user to select a card.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE        DESCRIPTION
      ----------------------------------------------------------
      player      int         This variable stores the index of the player who's turn it is.
      turn        String      This variable is used to display who's turn it is in the title section.
      f           Font        This variable is the font used for drawString.
      choice      String[]    This variable is the array of the category and value that the user selected.
      a           String      This variable is a temporary variable to store the input of the user.
      wager       int         This variable stores the wager that the user inputted if they selected a daily double.
      score       int         This variable stores the score of the current player.
      limit       int         This variable stores the maximum that a user is allowed to wager for a daily double.
      wagerStr    String      This variable stores the wager as a string.
      x           int         This variable stores the x position for the string in the game results screen.

      Global Variables:
      NAME            TYPE            DESCRIPTION
      ----------------------------------------------------------
      board           String[][]      This variable stores the dollar amounts in each card.
      playerNames     String[]        This variable stores the current playerNames.
      categories      String[]        This variable stores the 5 categories currently being used.
      dailyDoubles    int[][]         This variable stores which card is a daily double.
      scores          int[]           This variable stores the players' current scores.
      playerOneTurn   boolean         This variable stores whether it is player one's turn or not.

      ----------------------------------------------------------
      No input/logic/loop is used.
    */
    private void round3 ()
    {
	Font f = new Font ("serif", Font.BOLD, 24);
	c.setFont (f);
	title ("Final Round");
	c.setCursor (2, 1);
	c.print (playerNames [0] + ":");
	c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
	c.print (playerNames [1] + ":");
	c.print ("$" + scores [0]);
	String cat = "Category: " + categories [0];
	c.print (' ', 40 - cat.length () / 2 - String.valueOf (scores [0]).length () - 1);
	c.print (cat);
	c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
	c.print ("$" + scores [1]);

	int[] plrs = new int [playerNames.length];
	for (int i = 0 ; i < scores.length ; i++)
	    if (scores [i] < 0)
	    {
		c.println (playerNames [i] + " was disqualified from the final round for having a negative score.");
		plrs [i] = 0;
	    }
	    else
		plrs [i] = 1;

	if (plrs.length == 0)
	{
	    c.println ("No one qualified for the final round!");
	    c.println ("Press any key to continue...");
	}
	else
	{
	    c.println ("\n\nEach players will have 30 seconds to respond to the final round question");
	    c.println ("Press any key to begin the Final Round...");
	    c.getChar ();

	    int[] bets = new int [2];
	    for (int i = 0 ; i < plrs.length ; i++)
	    {
		title ("Final Round");
		c.setCursor (2, 1);
		c.print (playerNames [0] + ":");
		c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
		c.print (playerNames [1] + ":");
		c.print ("$" + scores [0]);
		c.print (' ', 40 - cat.length () / 2 - String.valueOf (scores [0]).length () - 1);
		c.print (cat);
		c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
		c.print ("$" + scores [1]);

		if (plrs [i] == 1)
		{
		    c.println ("\n\n\n\n");
		    c.println ("How much would " + playerNames [i] + " like to bet? ");
		    while (true)
		    {
			String a = c.readLine ();
			try
			{
			    bets [i] = Integer.parseInt (a);
			    break;
			}
			catch (NumberFormatException e)
			{
			    new Message ("Must be an integer! Try again!");
			}
		    }
		}
	    }

	    String[] finalAnswers = new String [2];
	    for (int i = 0 ; i < plrs.length ; i++)
	    {
		title ("Final Round");
		c.setCursor (2, 1);
		c.print (playerNames [0] + ":");
		c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
		c.print (playerNames [1] + ":");
		c.print ("$" + scores [0]);
		c.print (' ', 40 - cat.length () / 2 - String.valueOf (scores [0]).length () - 1);
		c.print (cat);
		c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
		c.print ("$" + scores [1]);

		if (plrs [i] == 1)
		{
		    c.println ("\n\n\n\n");
		    c.println (questions [0] [1]);
		    c.println ("\n\n");
		    c.println (playerNames [i] + ":");
		    c.print ("Who/What is ");
		    Date d = new Date ();
		    long t = d.getTime ();
		    finalAnswers [i] = c.readLine ();

		    Date d2 = new Date ();
		    long t2 = d2.getTime ();
		    if (t2 > t + 30000)
		    {
			c.println ("You took too long! Answer not accepted.");
			finalAnswers [i] = "";
		    }
		    c.println ("Press any key to continue...");
		    c.getChar ();
		}
	    }

	    title ("Final Round");
	    c.setCursor (2, 1);
	    c.print (playerNames [0] + ":");
	    c.print (' ', 80 - playerNames [0].length () - playerNames [1].length () - 2);
	    c.print (playerNames [1] + ":");
	    c.print ("$" + scores [0]);
	    c.print (' ', 40 - cat.length () / 2 - String.valueOf (scores [0]).length () - 1);
	    c.print (cat);
	    c.print (' ', 80 - c.getColumn () - String.valueOf (scores [1]).length ());
	    c.print ("$" + scores [1]);

	    for (int i = 0 ; i < plrs.length ; i++)
	    {

		if (plrs [i] == 1)
		{
		    c.println ();
		    if (finalAnswers [i].toLowerCase ().equals (answers [0] [1].toLowerCase ()))
		    {
			c.println (playerNames [i] + " was correct!");
			scores [i] += bets [i];
		    }
		    else
		    {
			c.println (playerNames [i] + " was incorrect!");
			c.println ("The correct answer was \"" + answers [0] [1] + "\"");
			scores [i] -= bets [i];
		    }
		}
	    }
	    c.println ("Press any key to continue...");
	    c.getChar ();
	}

	title ("Game Results");
	int winner, loser;
	if (scores [0] == scores [1])
	{
	    c.setColor (Color.green);
	    for (int i = 0 ; i < 300 ; i++)
	    {
		c.fillRect (100, 500 - i, 200, i);
		c.fillRect (340, 500 - i, 200, i);

		try
		{
		    Thread.sleep (2);
		}
		catch (Exception e)
		{
		}
	    }
	    c.setColor (Color.black);
	    c.setFont (new Font ("serif", Font.BOLD, 30));
	    int x = (int) (200 - f.getStringBounds (playerNames [0], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString (playerNames [0], x, 190);
	    x = (int) (440 - f.getStringBounds (playerNames [1], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString (playerNames [1], x, 190);
	    c.setColor (Color.white);
	    x = (int) (200 - f.getStringBounds ("$" + scores [0], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString ("$" + scores [0], x, 490);
	    x = (int) (440 - f.getStringBounds ("$" + scores [1], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString ("$" + scores [1], x, 490);
	}
	else if (scores [0] > scores [1])
	{
	    winner = 0;
	    loser = 1;
	    c.setColor (Color.green);
	    for (int i = 0 ; i < 300 ; i++)
	    {
		c.fillRect (100, 500 - i, 200, i);
		c.fillRect (340, 600 - i, 200, i);

		try
		{
		    Thread.sleep (2);
		}
		catch (Exception e)
		{
		}
	    }
	    c.setColor (Color.black);
	    c.setFont (new Font ("serif", Font.BOLD, 30));
	    int x = (int) (200 - f.getStringBounds (playerNames [winner], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString (playerNames [winner], x, 190);
	    x = (int) (440 - f.getStringBounds (playerNames [loser], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString (playerNames [loser], x, 290);
	    c.setColor (Color.white);
	    x = (int) (200 - f.getStringBounds ("$" + scores [winner], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString ("$" + scores [winner], x, 490);
	    x = (int) (440 - f.getStringBounds ("$" + scores [loser], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString ("$" + scores [loser], x, 490);
	}
	else
	{
	    winner = 1;
	    loser = 0;
	    c.setColor (Color.green);
	    for (int i = 0 ; i < 300 ; i++)
	    {
		c.fillRect (100, 500 - i, 200, i);
		c.fillRect (340, 600 - i, 200, i);

		try
		{
		    Thread.sleep (2);
		}
		catch (Exception e)
		{
		}
	    }
	    c.setColor (Color.black);
	    c.setFont (new Font ("serif", Font.BOLD, 30));
	    int x = (int) (200 - f.getStringBounds (playerNames [winner], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString (playerNames [winner], x, 190);
	    x = (int) (440 - f.getStringBounds (playerNames [loser], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString (playerNames [loser], x, 290);
	    c.setColor (Color.white);
	    x = (int) (200 - f.getStringBounds ("$" + scores [winner], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString ("$" + scores [winner], x, 490);
	    x = (int) (440 - f.getStringBounds ("$" + scores [loser], new FontRenderContext (new AffineTransform (), true, true)).getWidth () / 2);
	    c.drawString ("$" + scores [loser], x, 490);
	}
	c.println ();

	BufferedReader input;
	int[] hscores = new int [10];
	String[] tmp = new String [10];
	int total;
	try
	{
	    input = new BufferedReader (new FileReader ("lib/highscores.txt"));
	    for (int i = 0 ; i < 10 ; i++)
	    {
		tmp [i] = input.readLine ();
	    }
	}
	catch (IOException e)
	{
	}

	for (int a = 0 ; a < scores.length ; a++)
	{
	    total = 0;
	    for (int i = 0 ; i < 10 ; i++)
	    {
		if (tmp [i] != null)
		{
		    hscores [i] = Integer.parseInt (tmp [i].split (":") [1]);
		    total++;
		}
	    }

	    int min = hscores [0];
	    for (int i = 1 ; i < hscores.length ; i++)
		if (hscores [i] < min)
		    min = hscores [i];

	    if (scores [a] >= min)
	    {
		tmp [indexInArray (hscores, min)] = playerNames [a] + ":" + scores [a];
	    }
	}

	PrintWriter output;
	try
	{
	    output = new PrintWriter (new FileWriter ("lib/highscores.txt"));
	    for (int x = 0 ; x < tmp.length ; x++)
		if (tmp [x] != null)
		    output.println (tmp [x]);
	    output.close ();
	}
	catch (IOException e)
	{
	}

	c.println ("Press any key to continue...");
	c.getChar ();
    }


    /*
      This method displays the title of the program and an animation.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      l           Logo              This variable is the reference variable for the Logo class.
      s           Subtitle          This variable is the reference variable for the Subtitle class.
      m           Money             This variable is the reference variable for the Moeny class.

      Global Variables: None.
      ----------------------------------------------------------
      No input/logic/loop is used.
    */
    public void splashscreen ()
    {
	Logo l = new Logo (c);
	l.start ();
	Subtitle s = new Subtitle (c);
	s.start ();
	try
	{
	    s.join ();
	}
	catch (InterruptedException e)
	{
	}
	Money m = new Money (c);
	m.start ();

	try
	{
	    m.join ();
	}
	catch (InterruptedException e)
	{
	}

	c.setCursor (25, 40 - "Press any key to continue...".length () / 2);
	c.print ("Press any key to continue...");
	c.getChar ();
    }


    /*
      This method displays the title of the program and an animation.
      ----------------------------------------------------------
      Local Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      roundOver   boolean           This variable stores whether the current round is over or not.
      opt         String            This variable stores the option that the user selected.
      rand        int               This variable stores a random number from 1-25 for the random daily double card.

      Global Variables:
      NAME        TYPE              DESCRIPTION
      ----------------------------------------------------------
      board           String[][]      This variable stores the dollar amounts in each card.
      playerNames     String[]        This variable stores the current playerNames.
      dailyDoubles    int[][]         This variable stores which card is a daily double.

      ----------------------------------------------------------
      No input/logic/loop is used.
    */
    public void mainMenu ()
    {
	boolean roundOver;
	title ("Main Menu");
	c.println ("\n\n\n\n\n");
	c.print (' ', 40 - "[1]: Play Jeopardy!".length () / 2);
	c.println ("[1]: Play Jeopardy!");
	c.print (' ', 40 - "[1]: Play Jeopardy!".length () / 2);
	c.println ("[2]: How to Play");
	c.print (' ', 40 - "[1]: Play Jeopardy!".length () / 2);
	c.println ("[3]: High Scores");
	c.print (' ', 40 - "[1]: Play Jeopardy!".length () / 2);
	c.println ("[4]: Exit");
	c.println ("\n\n");
	c.print (' ', 15);
	c.print ("What would you like to do? ");
	String opt = c.readLine ();
	if (opt.equals ("1"))
	{
	    c.println ("What is Player 1's name? ");
	    playerNames [0] = c.readLine ();
	    c.println ("What is Player 2's name? ");
	    playerNames [1] = c.readLine ();

	    //Round 1
	    getRandCategories ();
	    getQuestions ();
	    for (int col = 0 ; col < board.length ; col++)
	    {
		for (int row = 0 ; row < board [col].length ; row++)
		{
		    board [col] [row] = "$" + ((row + 1) * 100);
		}
	    }
	    int rand = (int) (Math.random () * 25);
	    dailyDoubles [rand / 5] [rand % 5] = 1;
	    roundOver = false;
	    while (!roundOver)
	    {
		round1 ();
		out:
		for (int col = 0 ; col < 5 ; col++)
		{
		    for (int row = 0 ; row < 5 ; row++)
		    {
			if (board [col] [row] != "")
			{
			    roundOver = false;
			    break out;
			}
			else
			    roundOver = true;
		    }
		}
	    }

	    //Round 2
	    getRandCategories ();
	    getQuestions ();
	    for (int col = 0 ; col < board.length ; col++)
	    {
		for (int row = 0 ; row < board [col].length ; row++)
		{
		    board [col] [row] = "$" + ((row + 1) * 200);
		}
	    }
	    dailyDoubles = new int [5] [5];
	    rand = (int) (Math.random () * 25);
	    dailyDoubles [rand / 5] [rand % 5] = 1;
	    while (true)
	    {
		rand = (int) (Math.random () * 25);
		if (dailyDoubles [rand / 5] [rand % 5] != 1)
		{
		    dailyDoubles [rand / 5] [rand % 5] = 1;
		    break;
		}
	    }
	    roundOver = false;
	    while (!roundOver)
	    {
		round2 ();
		out:
		for (int col = 0 ; col < 5 ; col++)
		{
		    for (int row = 0 ; row < 5 ; row++)
		    {
			if (board [col] [row] != "")
			{
			    roundOver = false;
			    break out;
			}
			else
			    roundOver = true;
		    }
		}
	    }

	    //Round 3
	    getRandCategories ();
	    getQuestions ();
	    for (int col = 0 ; col < board.length ; col++)
	    {
		for (int row = 0 ; row < board [col].length ; row++)
		{
		    board [col] [row] = "$" + ((row + 1) * 200);
		}
	    }
	    roundOver = false;
	    round3 ();

	    categories = new String [5];
	    board = new String [5] [5];
	    playerOneTurn = true;
	    playerNames = new String [2];
	    scores = new int [2];
	    questions = new String [5] [5];
	    answers = new String [5] [5];
	    oldCategories = new String [10];
	    dailyDoubles = new int [5] [5];
	}
	else if (opt.equals ("2"))
	{
	    instructions ();
	}
	else if (opt.equals ("3"))
	{
	    highscore ();
	}
	else if (opt.equals ("4"))
	{
	    done = true;
	}
	else
	{
	    new Message ("Invalid option! Try again!");
	}
    }


    /*
      This method displays a goodbye message and exits.
      -----------------------------
      Local Variables: None.
      Global Variables: None.
      -----------------------------
      No input/logic/loop is used.
    */
    public void goodbye ()
    {
	title ("Jeopardy");

	c.println ("\n\n\n\n");
	c.print (' ', 40 - "Thanks for playing Jeopardy! This game was created by Josh Friedman.".length () / 2);
	c.println ("Thanks for playing Jeopardy! This game was created by Josh Friedman.");
	c.println ();
	c.print (' ', 40 - "Press any key to continue...".length () / 2);
	c.println ("Press any key to continue...");
	c.getChar ();
	c.close ();
    }


    /*
      This method is the main method that controls the flow of the program.
      -----------------------------
      Local Variables: j (The reference variable for the Jeopardy class.)
      Global Variables: None.
      -----------------------------
      The while loop runs until the user chooses to exit.
    */
    public static void main (String[] args)
    {
	c = new Console ();
	Jeopardy j = new Jeopardy ();
	j.splashscreen ();
	while (!done)
	    j.mainMenu ();
	j.goodbye ();
    } // main method
} // Jeopardy class


