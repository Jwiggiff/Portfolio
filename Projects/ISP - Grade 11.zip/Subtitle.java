/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 01/16/2019
   This class animates the Subtitle coming up from the bottom of the screen.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Subtitle extends Thread
{
    private Console c;

    public void subtitle ()
    {
	//local variable for logo colour
	Color blue = new Color (12, 115, 227);
	Font f = new Font ("serif", Font.BOLD, 30);

	//loop used to animate the subtitle coming down
	for (int x = 526 ; x >= 250 ; x--)
	{
	    c.setColor (Color.white);
	    c.fillRect (128, x - 21, 383, 27);
	    c.setColor (blue);
	    c.setFont (f);
	    c.drawString ("America's Favorite Quiz Show", 128, x);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (2);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Subtitle (Console con)
    {
	c = con;
    }


    public void run ()
    {
	subtitle ();
    }
}



