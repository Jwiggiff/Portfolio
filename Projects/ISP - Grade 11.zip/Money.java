/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 01/16/2019
   This class animates the Money coming down from the side of the screen.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Money extends Thread
{
    private Console c;

    public void money ()
    {
	//Local variable for font for dollar sign
	Font f = new Font ("serif", Font.BOLD, 150);

	//loop used to animate the money coming from the left
	for (int x = -400 ; x <= 120 ; x++)
	{
	    c.setColor (Color.white);
	    c.fillRect (x - 1, 290, 401, 430);
	    c.setColor (Color.green);
	    c.fillRect (x, 290, 400, 175);
	    c.setFont (f);
	    c.setColor (Color.black);
	    c.drawString ("$", x + 163, 430);
	    c.setColor (Color.red);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (2);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Money (Console con)
    {
	c = con;
    }


    public void run ()
    {
	money ();
    }
}



