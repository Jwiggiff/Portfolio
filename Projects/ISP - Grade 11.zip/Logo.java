/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 01/16/2019
   This class animates the Logo coming down from the top of the screen.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class
import java.io.*;

public class Logo extends Thread
{
    private Console c;

    public void logo ()
    {
	//local variable for light blue colour
	Color blue = new Color (12, 115, 227);
	Font f = new Font ("serif", Font.BOLD, 150);

	//loop used to animate the logo coming down
	for (int x = -32 ; x <= 175 ; x++)
	{
	    c.setColor (Color.white);
	    c.fillRect (21, x - 101, 598, 133);
	    c.setColor (blue);
	    c.setFont (f);
	    c.drawString ("Jeopardy", 21, x);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (2);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Logo (Console con)
    {
	c = con;
    }


    public void run ()
    {
	logo ();
    }
}



