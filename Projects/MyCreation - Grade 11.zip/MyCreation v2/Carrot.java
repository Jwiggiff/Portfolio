/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This class animates a carrot growing.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Carrot extends Thread
{
    private Console c;

    public void carrot ()
    {
	//local variable for colour of the plant
	Color plant = new Color (19, 129, 28);
	//local variable for carrot
	Color carrot = new Color (255, 112, 0);
	//local variable for erase
	Color erase = new Color (53, 179, 16);

	//loop to animate top of carrot coming out of ground
	for (int x = 0 ; x < 16 ; x++)
	{
	    c.setColor (carrot);
	    c.fillArc (432, 388 - x, 16, x * 2, 0, 180);

	    try
	    {
		Thread.sleep (100);
	    }
	    catch (Exception e)
	    {
	    }
	}

	//loop to animate stem of carrot plant
	for (int x = 0 ; x < 32 ; x++)
	{
	    c.setColor (plant);
	    c.fillRect (438, 374 - x, 4, x);

	    try
	    {
		Thread.sleep (50);
	    }
	    catch (Exception e)
	    {
	    }
	}

	//loop to animate leaves of carrot plant
	for (int x = 0 ; x < 16 ; x++)
	{
	    c.setColor (erase);
	    c.fillRect (422, 356, 16, 8);
	    c.setColor (erase);
	    c.fillRect (442, 340, 16, 8);
	    c.setColor (plant);
	    c.fillArc (438 - x, 356, x, 16, 0, 180);
	    c.fillOval (442, 340, x, 8);
	    try
	    {
		Thread.sleep (50);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Carrot (Console con)
    {
	c = con;
    }


    public void run ()
    {
	carrot ();
    }
}



