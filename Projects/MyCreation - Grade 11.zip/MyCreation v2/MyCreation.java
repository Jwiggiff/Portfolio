/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   Assignment: This is an animation that animates a pumpkin growing in a farm while the days past by,
    followed by a farmer coming and harvesting the pumpkin. Then a potato grows while the days pass by,
    and the same farmer comes in a different colour shirt and harvests the potato. Finally, a carrot grows
    while the days pass by, and the same farmer comes in a different colour shirt and walking slightly faster and harvests the carrot.
*/

// The "MyCreation" class.
import java.awt.*;
import hsa.Console;


public class MyCreation
{
    Console c;           // The output console

    //adds the Background thread to MyCreation
    public void background ()
    {
	Background b = new Background (c);
    }


    //adds the Intro thread to MyCreation
    public void intro ()
    {
	Intro in = new Intro (c);
    }


    //adds the Pumpkin thread to MyCreation
    public void pumpkin ()
    {
	//creates the thread
	Pumpkin p = new Pumpkin (c);
	//starts the thread
	p.start ();
    }


    //adds the Potato thread to MyCreation
    public void potato ()
    {
	//creates the thread
	Potato po = new Potato (c);
	//starts the thread
	po.start ();
    }


    //adds the Carrot thread to MyCreation
    public void carrot ()
    {
	//creates the thread
	Carrot ca = new Carrot (c);
	//starts the thread
	ca.start ();
    }


    //adds the Farmer thread to MyCreation
    public void farmer ()
    {
	//creates the thread
	Farmer f = new Farmer (c);
	//starts the thread
	f.run ();
    }


    //adds the Farmer thread to MyCreation
    public void farmer (Color col)
    {
	//creates the thread
	Farmer f = new Farmer (c, col);
	//starts the thread
	f.run ();
    }


    //adds the Farmer thread to MyCreation
    public void farmer (Color col, int speed)
    {
	//creates the thread
	Farmer f = new Farmer (c, col, speed);
	//starts the thread
	f.run ();
    }


    //adds the Sun thread to MyCreation
    public void sun ()
    {
	//creates the thread
	Sun i = new Sun (c);
	//starts the thread
	i.start ();

	// joins with moon thread so that the moon doesn't start until the sun thread ends
	try
	{
	    i.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    //adds the Moon thread to MyCreation
    public void moon ()
    {
	//creates the thread
	Moon m = new Moon (c);
	//starts the thread
	m.start ();

	// joins with sun thread so that the sun doesn't start until the moon thread ends
	try
	{
	    m.join ();
	}
	catch (InterruptedException e)
	{
	}
    }


    //creates a new window and gives window a title
    public MyCreation ()
    {
	c = new Console ("Plants growing in a farm");
    }


    public static void main (String[] args)
    {
	MyCreation z = new MyCreation ();

	z.intro ();
	z.background ();
	z.pumpkin ();
	for (int x = 0 ; x < 2 ; x++)
	{
	    z.sun ();
	    z.moon ();
	}
	z.farmer ();
	z.potato ();
	for (int x = 0 ; x < 2 ; x++)
	{
	    z.sun ();
	    z.moon ();
	}
	z.farmer (new Color (207, 12, 12));
	z.carrot ();
	for (int x = 0 ; x < 2 ; x++)
	{
	    z.sun ();
	    z.moon ();
	}
	z.farmer (new Color (255, 112, 0), 10);
    }
} // MyCreation class


