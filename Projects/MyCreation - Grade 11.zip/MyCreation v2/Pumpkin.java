/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This class animates a pumpkin growing.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Pumpkin extends Thread
{
    private Console c;

    public void pumpkin ()
    {
	//local variable for colour of pumpkin
	Color pumpkin = new Color (255, 118, 25);
	//local variable for colour of stem
	Color stem = new Color (19, 129, 28);
	//local variable for colour of the erase
	Color erase = new Color (53, 179, 16);

	//loop used to animate the stem growing
	for (int x = 0 ; x < 80 ; x++)
	{
	    c.setColor (stem);
	    c.drawLine (490, 388 - x, 506, 388 - x);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (50);
	    }
	    catch (Exception e)
	    {
	    }
	}

	//loop used to animate the second part of the stem growing
	for (int x = 0 ; x < 80 ; x++)
	{
	    c.setColor (stem);
	    c.fillArc (506 - x, 308, x, 32, 0, 180);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (50);
	    }
	    catch (Exception e)
	    {
	    }
	}

	//loop used to animate the pumpkin growing
	for (int x = 0 ; x < 50 ; x += 5)
	{
	    c.setColor (pumpkin);
	    c.fillOval (434 - x, 323, x * 2, 64);

	    c.setColor (Color.black);
	    c.drawOval (434 - x, 323, x * 2, 64);
	    c.setColor (Color.black);
	    c.drawOval (434 - x * 2 / 3, 323, x * 4 / 3, 64);
	    c.setColor (Color.black);
	    c.drawOval (434 - x * 2 / 6, 323, x * 2 / 3, 64);
	    c.setColor (Color.black);
	    c.drawLine (434, 323, 434, 388);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (100);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Pumpkin (Console con)
    {
	c = con;
    }


    public void run ()
    {
	pumpkin ();
    }
}



