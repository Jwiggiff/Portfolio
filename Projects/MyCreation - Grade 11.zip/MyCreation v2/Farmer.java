/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This class animates a farmer coming, harvesting the plant, and leaving.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Farmer implements Runnable
{
    private Console c;
    private Color shirt; //variable for colour of shirt
    private int delay = 25; //variable for speed of farmer

    public void farmer ()
    {
	//local variable for colour of the farmer's skin
	Color skin = new Color (255, 173, 96);
	//local variable for colour of the hat
	Color hat = new Color (251, 216, 25);
	//local variable fro colour of the erase
	Color erase = new Color (53, 179, 16);

	//loop used to animate the farmer going to the plant
	for (int x = -81 ; x < 187 ; x++)
	{
	    //erase farmer
	    c.setColor (erase);
	    c.fillRect (561 - x, 228, 81, 17);
	    c.fillRect (577 - x, 244, 49, 144);

	    c.setColor (skin);
	    c.fillOval (576 - x, 228, 48, 48);
	    c.setColor (Color.white);
	    c.fillOval (584 - x, 244, 8, 8);
	    c.setColor (Color.black);
	    c.fillOval (584 - x, 248, 4, 4);
	    c.setColor (shirt);
	    c.fillArc (576 - x, 276, 48, 32, 0, 180);
	    c.fillRect (576 - x, 292, 48, 64);
	    c.setColor (hat);
	    c.fillArc (576 - x, 228, 48, 32, 0, 180);
	    c.setColor (Color.black);
	    c.drawLine (560 - x, 244, 640 - x, 244);
	    c.drawArc (576 - x, 252, 16, 16, 270, 90);
	    c.fillRect (576 - x, 356, 16, 32);
	    c.fillRect (608 - x, 356, 16, 32);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (delay);
	    }
	    catch (Exception e)
	    {
	    }
	}
	//loop used to animate the farmer coming back
	for (int x = 187 ; x >= -81 ; x--)
	{
	    //erase farmer
	    c.setColor (erase);
	    c.fillRect (559 - x, 228, 80, 17);
	    c.fillRect (575 - x, 244, 48, 144);

	    c.setColor (skin);
	    c.fillOval (576 - x, 228, 48, 48);
	    c.setColor (Color.white);
	    c.fillOval (584 - x, 244, 8, 8);
	    c.setColor (Color.black);
	    c.fillOval (584 - x, 248, 4, 4);
	    c.setColor (shirt);
	    c.fillArc (576 - x, 276, 48, 32, 0, 180);
	    c.fillRect (576 - x, 292, 48, 64);
	    c.setColor (hat);
	    c.fillArc (576 - x, 228, 48, 32, 0, 180);
	    c.setColor (Color.black);
	    c.drawLine (560 - x, 244, 640 - x, 244);
	    c.drawArc (576 - x, 252, 16, 16, 270, 90);
	    c.fillRect (576 - x, 356, 16, 32);
	    c.fillRect (608 - x, 356, 16, 32);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (delay);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Farmer (Console con)
    {
	c = con;
	shirt = new Color (47, 46, 255);
    }


    public Farmer (Console con, Color col)
    {
	c = con;
	shirt = col;
    }


    public Farmer (Console con, Color col, int speed)
    {
	c = con;
	shirt = col;
	delay = speed;
    }


    public void run ()
    {
	farmer ();
    }
}



