/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This class animates a sun moving across the sky.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Moon extends Thread
{
    private Console c;

    public void moon ()
    {
	//local variable for sky colour
	Color skyblue = new Color (12, 115, 227);
	//local variable for the colour of the sun
	Color moonwhite = new Color (229, 229, 198);

	//loop used for animate the moon going across the sky
	for (int x = -96 ; x <= 640 ; x++)
	{
	    double y = -1.0000 / 1280 * Math.pow (x - 320, 2) + 80;
	    int z = (int) Math.round (y);

	    //Erase moon
	    c.setColor (skyblue);
	    c.fillRect (-1 + x, 79 - z, 97, 99);

	    c.setColor (moonwhite);
	    c.fillOval (16 + x, 96 - z, 64, 64);
	    c.fillStar (8 + x, 88 - z, 16, 16);
	    c.fillStar (72 + x, 88 - z, 16, 16);
	    c.fillStar (8 + x, 152 - z, 16, 16);
	    c.fillStar (72 + x, 152 - z, 16, 16);

	    c.setColor (Color.black);
	    c.drawArc (32 + x, 112 - z, 16, 16, 180, 180);
	    c.drawArc (48 + x, 112 - z, 16, 16, 180, 180);
	    c.drawLine (40 + x, 144 - z, 56 + x, 144 - z);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (2);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Moon (Console con)
    {
	c = con;
    }


    public void run ()
    {
	moon ();
    }
}



