/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This class animates a potato growing.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Potato extends Thread
{
    private Console c;

    public void potato ()
    {
	//local variable for colour of the plant
	Color plant = new Color (19, 129, 28);
	//local variable for erase
	Color erase = new Color (53, 179, 16);

	//loop to animate the stem growing
	for (int x = 0 ; x < 80 ; x++)
	{
	    c.setColor (plant);
	    c.drawLine (432, 388 - x, 448, 388 - x);
	    c.setColor (Color.black);
	    c.drawLine (440, 388, 440, 388 - x);

	    try
	    {
		Thread.sleep (10);
	    }
	    catch (Exception e)
	    {
	    }
	}

	//loop to animate the top of the stem growing
	for (int x = 0 ; x < 24 ; x++)
	{
	    c.setColor (plant);
	    c.fillMapleLeaf (432, 316 - x, 16, x);

	    try
	    {
		Thread.sleep (10);
	    }
	    catch (Exception e)
	    {
	    }
	}

	//loop to animate leaves growing
	for (int x = 0 ; x < 32 ; x++)
	{
	    c.setColor (erase);
	    c.fillRect (400, 308, 32, 16);
	    c.setColor (erase);
	    c.fillRect (448, 324, 32, 16);
	    c.setColor (erase);
	    c.fillRect (400, 356, 32, 16);
	    c.setColor (plant);
	    c.fillArc (432 - x, 308, x, 32, 0, 180);
	    c.fillArc (448, 324, x, 32, 0, 180);
	    c.fillArc (432 - x, 356, x, 32, 0, 180);

	    try
	    {
		Thread.sleep (100);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Potato (Console con)
    {
	c = con;
    }


    public void run ()
    {
	potato ();
    }
}



