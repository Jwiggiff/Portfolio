/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This is the background class.
*/


import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Background
{
    //global variable used to store the Console
    private Console c;

    //method to draw background
    public void draw ()
    {
	//local variable for sky colour
	Color skyblue = new Color (12, 115, 227);
	//local variables for various greens for trees, hills, grass, and flower stems
	Color green1 = new Color (53, 179, 16);
	Color green2 = new Color (39, 133, 10);
	Color green3 = new Color (38, 125, 12);
	Color green4 = new Color (76, 146, 54);
	Color green5 = new Color (19, 129, 28);
	//local variable for tree trunk colour
	Color brown = new Color (165, 42, 42);
	//local variables for various flower colours
	Color purple = new Color (181, 36, 243);
	Color red = new Color (249, 7, 7);
	Color orange = new Color (255, 112, 0);

	//loop to draw sky
	for (int x = 0 ; x <= 388 ; x++)
	{
	    c.setColor (skyblue);
	    c.drawLine (0, x, 640, x);
	}

	//loop to draw middle hill
	for (int x = 0 ; x < 216 ; x++)
	{
	    c.setColor (green3);
	    c.drawOval (272 - x, 160, 2 * x, 448);
	    c.drawOval (273 - x, 160, 2 * x, 448);
	}

	//loop to draw left hill
	for (int x = 0 ; x < 160 ; x++)
	{
	    c.setColor (green1);
	    c.drawOval (64 - x, 240, 2 * x, 384);
	    c.drawOval (65 - x, 240, 2 * x, 384);
	}

	//loop to draw right hill
	for (int x = 0 ; x < 324 ; x++)
	{
	    c.setColor (green1);
	    c.drawOval (560 - x, 192, 2 * x, 384);
	    c.drawOval (561 - x, 192, 2 * x, 384);
	}

	//loop to draw grass
	for (int x = 388 ; x <= 500 ; x++)
	{
	    c.setColor (green2);
	    c.drawLine (0, x, 640, x);
	}

	//loop to draw tree trunk
	for (int x = 0 ; x < 48 ; x++)
	{
	    c.setColor (brown);
	    c.drawLine (x + 32, 224, x + 32, 388);
	}

	//loop to draw tree leaves
	for (int x = 0 ; x < 56 ; x++)
	{
	    c.setColor (green4);
	    c.drawOval (56 - x, 220, 2 * x, 80);
	    c.drawOval (57 - x, 220, 2 * x, 80);
	}

	//loop to draw flower stems
	for (int x = 0 ; x < 4 ; x++)
	{
	    c.setColor (green5);
	    c.drawLine (14 + x, 348, 14 + x, 388);
	    c.drawLine (94 + x, 372, 94 + x, 388);
	    c.drawLine (118 + x, 356, 118 + x, 388);
	    c.drawLine (134 + x, 364, 134 + x, 388);
	}

	//loop to draw flower heads
	for (int x = 0 ; x < 8 ; x++)
	{
	    c.setColor (purple);
	    c.drawOval (16 - x, 332, 2 * x, 16);
	    c.setColor (red);
	    c.drawOval (96 - x, 356, 2 * x, 16);
	    c.setColor (orange);
	    c.drawOval (120 - x, 340, 2 * x, 16);
	    c.setColor (purple);
	    c.drawOval (136 - x, 348, 2 * x, 16);
	}
    }


    public Background (Console con)
    {
	c = con;
	draw ();
    }
}


