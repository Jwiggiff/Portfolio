/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This class animates a sun moving across the sky.
*/

import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Sun extends Thread
{
    private Console c;

    public void sun ()
    {
	//local variable for sky colour
	Color skyblue = new Color (12, 115, 227);
	//local variable for the colour of the sun
	Color yellow = new Color (236, 232, 17);
	//local variable for the color of the glasses
	Color black = new Color (0, 0, 0);

	//loop used for animate the sun going across the sky
	for (int x = -96 ; x <= 640 ; x++)
	{
	    double y = -1.0000 / 1280 * Math.pow (x - 320, 2) + 80;
	    int z = (int) Math.round (y);

	    //Erase sun
	    c.setColor (skyblue);
	    c.fillRect (-1 + x, 79 - z, 97, 99);

	    c.setColor (yellow);
	    c.fillOval (16 + x, 96 - z, 64, 64);
	    c.drawLine (8 + x, 88 - z, 24 + x, 104 - z);
	    c.drawLine (48 + x, 80 - z, 48 + x, 96 - z);
	    c.drawLine (88 + x, 88 - z, 72 + x, 104 - z);
	    c.drawLine (80 + x, 128 - z, 96 + x, 128 - z);
	    c.drawLine (72 + x, 144 - z, 88 + x, 168 - z);
	    c.drawLine (48 + x, 160 - z, 48 + x, 176 - z);
	    c.drawLine (8 + x, 168 - z, 24 + x, 152 - z);
	    c.drawLine (0 + x, 128 - z, 16 + x, 128 - z);

	    c.setColor (black);
	    c.fillRect (24 + x, 112 - z, 50, 4);
	    c.fillArc (32 + x, 96 - z, 16, 32, 180, 180);
	    c.fillArc (48 + x, 96 - z, 16, 32, 180, 180);

	    c.drawArc (32 + x, 128 - z, 32, 16, 180, 180);

	    //used to delay the animation
	    try
	    {
		Thread.sleep (2);
	    }
	    catch (Exception e)
	    {
	    }
	}
    }


    public Sun (Console con)
    {
	c = con;
    }


    public void run ()
    {
	sun ();
    }
}



