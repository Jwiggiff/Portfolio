/*
   Name: Josh Friedman
   Teacher: Mr. Rosen
   Date: 10/22/2018
   This is the intro class.
*/


import java.awt.*;
import hsa.Console;
import java.lang.*;     // to access Thread class

public class Intro
{
    //global variable used to store the Console
    private Console c;

    //method to draw intro
    public void draw ()
    {
	//local variable for big font
	Font bigFont = new Font ("Roboto", Font.BOLD, 50);
	//local variable for smaller font
	Font smallFont = new Font ("Roboto", Font.BOLD, 25);

	c.setColor (Color.black);
	c.setFont (bigFont);
	c.drawString ("Plants in a Farm", 117, 250);

	c.setFont (smallFont);
	c.drawString ("By Josh Friedman", 211, 300);

	try
	{
	    Thread.sleep (4000);
	}
	catch (Exception e)
	{
	}
    }


    public Intro (Console con)
    {
	c = con;
	draw ();
    }
}


